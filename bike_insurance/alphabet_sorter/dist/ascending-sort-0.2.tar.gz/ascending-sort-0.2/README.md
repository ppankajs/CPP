# Ascending Sort Library

This is a simple Python library to sort a list of strings in ascending alphabetical order.

## Installation

To install the library:

```bash
pip install ascending_sort
