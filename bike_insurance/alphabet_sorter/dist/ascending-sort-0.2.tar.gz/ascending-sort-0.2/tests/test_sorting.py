from ascending_sort import sort_alphabetically

input_list = ["banana", "apple", "cherry"]
sorted_list = sort_alphabetically(input_list)

print(sorted_list)  # ['apple', 'banana', 'cherry']
